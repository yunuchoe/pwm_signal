# stm32cube_fw_f0_v1111.zip

## STM32F0 HAL Drivers V1.7.4 / 24-July-2020

The `stm32f0xx_*.h` files were copied from the folder:

- `STM32Cube_FW_F0_V1.11.1/Drivers/STM32F0xx_HAL_Driver/Inc`
