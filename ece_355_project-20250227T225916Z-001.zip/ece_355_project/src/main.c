//
// This file is part of the GNU ARM Eclipse distribution.
// Copyright (c) 2014 Liviu Ionescu.
//

// ----------------------------------------------------------------------------
// School: University of Victoria, Canada.
// Course: ECE 355 "Microprocessor-Based Systems".
// This is template code for Part 2 of Introductory Lab.
//
// See "system/include/cmsis/stm32f051x8.h" for register/bit definitions.
// See "system/src/cmsis/vectors_stm32f051x8.c" for handler declarations.
// ----------------------------------------------------------------------------

#include <stdio.h>
#include "diag/Trace.h"
#include "stm32f051x8.h"
#include "cmsis/cmsis_device.h"

// ----------------------------------------------------------------------------
//
// STM32F0 empty sample (trace via $(trace)).
//
// Trace support is enabled by adding the TRACE macro definition.
// By default the trace messages are forwarded to the $(trace) output,
// but can be rerouted to any device or completely suppressed, by
// changing the definitions required in system/src/diag/trace_impl.c
// (currently OS_USE_TRACE_ITM, OS_USE_TRACE_SEMIHOSTING_DEBUG/_STDOUT).
//

// ----- main() ---------------------------------------------------------------

// Sample pragmas to cope with warnings. Please note the related line at
// the end of this function, used to pop the compiler diagnostics status.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wmissing-declarations"
#pragma GCC diagnostic ignored "-Wreturn-type"


/* Definitions of registers and their bits are
   given in system/include/cmsis/stm32f051x8.h */


/* Clock prescaler for TIM2 timer: no prescaling */
#define myTIM2_PRESCALER ((uint16_t)0x0000)
/* Maximum possible setting for overflow */
#define myTIM2_PERIOD ((uint32_t)0xFFFFFFFF)

void myGPIOA_Init(void);
void myTIM2_Init(void);
void myEXTI_Init(void);

void myADC_Init(void);
void myDAC_Init(void);

uint32_t Potentiometer_resistance();
uint32_t Potentiometer_voltage();
void read_DAC();

// Declare/initialize your global variables here...
// NOTE: You'll need at least one global variable
// (say, timerTriggered = 0 or 1) to indicate
// whether TIM2 has started counting or not.

uint32_t timerTriggered = 0;
uint32_t inSig = 0;


/*** Call this function to boost the STM32F0xx clock to 48 MHz ***/

void SystemClock48MHz( void )
{
//
// Disable the PLL
//
    RCC->CR &= ~(RCC_CR_PLLON);
//
// Wait for the PLL to unlock
//
    while (( RCC->CR & RCC_CR_PLLRDY ) != 0 );
//
// Configure the PLL for 48-MHz system clock
//
    RCC->CFGR = 0x00280000;
//
// Enable the PLL
//
    RCC->CR |= RCC_CR_PLLON;
//
// Wait for the PLL to lock
//
    while (( RCC->CR & RCC_CR_PLLRDY ) != RCC_CR_PLLRDY );
//
// Switch the processor to the PLL clock source
//
    RCC->CFGR = ( RCC->CFGR & (~RCC_CFGR_SW_Msk)) | RCC_CFGR_SW_PLL;
//
// Update the system with the new clock frequency
//
    SystemCoreClockUpdate();

}

/*****************************************************************/

int main(int argc, char* argv[])
{

	SystemClock48MHz();

	trace_printf("This is the Project\n");
	trace_printf("System clock: %u Hz\n", SystemCoreClock);

	myGPIOA_Init();		/* Initialize I/O port PA */
	myTIM2_Init();		/* Initialize timer TIM2 */
	myEXTI_Init();		/* Initialize EXTI */

	myADC_Init(); // initialize ADC
	myDAC_Init(); // initialize DAC

	while (1)
	{

		//refresh_oled();
	}
	return 0;

}



void myGPIOA_Init()
{
	/* Enable clock for GPIOA peripheral */
	// Relevant register: RCC->AHBENR
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;

	/* Configure PA2 as input */
	// Relevant register: GPIOA->MODER
	GPIOA->MODER &= ~(GPIO_MODER_MODER2);

	/* Ensure no pull-up/pull-down for PA2 */
	// Relevant register: GPIOA->PUPDR
	GPIOA->PUPDR &= ~(GPIO_PUPDR_PUPDR2);
}


void myTIM2_Init()
{
	/* Enable clock for TIM2 peripheral */
	// Relevant register: RCC->APB1ENR
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

	/* Configure TIM2: buffer auto-reload, count up, stop on overflow,
	 * enable update events, interrupt on overflow only */
	// Relevant register: TIM2->CR1
	TIM2->CR1 = ((uint16_t)0x008C);

	/* Set clock prescaler value */
	TIM2->PSC = myTIM2_PRESCALER;
	/* Set auto-reloaded delay */
	TIM2->ARR = myTIM2_PERIOD;

	/* Update timer registers */
	// Relevant register: TIM2->EGR
	TIM2->EGR = ((uint16_t)0x0001);

	/* Assign TIM2 interrupt priority = 0 in NVIC */
	// Relevant register: NVIC->IP[3], or use NVIC_SetPriority
	NVIC_SetPriority(TIM2_IRQn, 0);

	/* Enable TIM2 interrupts in NVIC */
	// Relevant register: NVIC->ISER[0], or use NVIC_EnableIRQ
	NVIC_EnableIRQ(TIM2_IRQn);

	/* Enable update interrupt generation */
	// Relevant register: TIM2->DIER
	TIM2->DIER |= TIM_DIER_UIE;
	/* Start counting timer pulses */ //maybe not needed (remove comment later)
	TIM2->CR1 |= TIM_CR1_CEN;
}


void myEXTI_Init()
{
	/* Map EXTI2 line to PA2 */
	// Relevant register: SYSCFG->EXTICR[0]
	SYSCFG->EXTICR[0] &= ~(SYSCFG_EXTICR1_EXTI2|SYSCFG_EXTICR1_EXTI0|SYSCFG_EXTICR1_EXTI1);

	/* EXTI2 line interrupts: set rising-edge trigger */
	// Relevant register: EXTI->RTSR
	EXTI->RTSR |= (EXTI_RTSR_TR0|EXTI_RTSR_TR1|EXTI_RTSR_TR2);

	/* Unmask interrupts from EXTI2 line */
	// Relevant register: EXTI->IMR
	EXTI->IMR |= (EXTI_IMR_MR0|EXTI_IMR_MR1|EXTI_IMR_MR2);

	/* Assign EXTI2 interrupt priority = 1 in NVIC */
	// Relevant register: NVIC->IP[2], or use NVIC_SetPriority
	NVIC_SetPriority(EXTI2_3_IRQn,1);

	/* Enable EXTI2 interrupts in NVIC */
	// Relevant register: NVIC->ISER[0], or use NVIC_EnableIRQ
	NVIC_EnableIRQ(EXTI2_3_IRQn);


	/* Assign EXTI1 interrupt priority = 0 in NVIC */
	NVIC_SetPriority(EXTI0_1_IRQn,0);

	/* Enable EXTI1 interrupts in NVIC */
	NVIC_EnableIRQ(EXTI0_1_IRQn);

}


/* This handler is declared in system/src/cmsis/vectors_stm32f051x8.c */
void TIM2_IRQHandler()
{
	/* Check if update interrupt flag is indeed set */
	if ((TIM2->SR & TIM_SR_UIF) != 0)
	{
		trace_printf("\n*** Overflow! ***\n");

		/* Clear update interrupt flag */
		// Relevant register: TIM2->SR
		TIM2->SR &= ~(TIM_SR_UIF);

		/* Restart stopped timer */
		// Relevant register: TIM2->CR1
		TIM2->CR1 |= TIM_CR1_CEN;
	}
}


/* This handler is declared in system/src/cmsis/vectors_stm32f051x8.c */

void EXTI0_1_IRQHandler(){
	// Declare/initialize your local variables here...
	double freq;
	uint32_t count;

	/* Check if EXTI1 interrupt pending flag is indeed set */
	// similar to lab 2 and repeat of exti2 below
	// this reads off adc
	if ((EXTI->PR & EXTI_PR_PR1) != 0) {
		/* This code section is for measuring frequency on
		EXTI1 when inSig = 0 */
		//read_DAC();

			// 1. If this is the first edge:
			//	- Clear count register (TIM2->CNT).
			//	- Start timer (TIM2->CR1).
			//    Else (this is the second edge):
			//	- Stop timer (TIM2->CR1).
			//	- Read out count register (TIM2->CNT).
			//	- Calculate signal period and frequency.
			//	- Print calculated values to the console.
			//	  NOTE: Function trace_printf does not work
			//	  with floating-point numbers: you must use
			//	  "unsigned int" type to print your signal
			//	  period and frequency.
				if((EXTI->PR & EXTI_PR_PR1) != 0){
					if(timerTriggered == 0){
						timerTriggered = 1;
						count = 0;

						TIM2->CNT = 0;

						TIM2->CR1 |= TIM_CR1_CEN;;
					}else{
						timerTriggered = 0;

						TIM2->CR1 &= ~(TIM_CR1_CEN);

						count = TIM2->CNT;

						freq = ((double)SystemCoreClock)/((double)count); // freq=1/period

						trace_printf("Source: Optocoupler\n");
						trace_printf("The Frequency is: %f Hz\n", freq);
						trace_printf("The Resistance is: %f ohms\n\n", (float)Potentiometer_resistance());
					}
				}
			if((EXTI->PR & EXTI_PR_PR0) != 0){ // is button pressed?
				while((GPIOA->IDR & GPIO_IDR_0) != 0){} // wait for button
				//trace_printf("\nButton hit\n");
				EXTI->IMR &= ~(EXTI_IMR_MR1); // disable this interupt (1)
			}

			// 2. Clear EXTI1 interrupt pending flag (EXTI->PR).
			// NOTE: A pending register (PR) bit is cleared
			// by writing 1 to it.
			EXTI->PR |= EXTI_PR_PR1;
	}


	if ((EXTI->PR & EXTI_PR_PR0) != 0) {
		/* If inSig = 0, then: let inSig = 1, disable
		EXTI1 interrupts, enable EXTI2 interrupts */
		/* Else: let inSig = 0, disable EXTI2 interrupts,
		enable EXTI1 interrupts */

		EXTI->PR |= 0x1; // clear interupt pending flag for exti 0

		while((GPIOA->IDR & GPIO_IDR_0) != 0){}
		//trace_printf("\nButton hit\n");

		if(inSig == 0){
			//trace_printf("Changing inSIG to 1");
			inSig = 1;
			EXTI->IMR &= ~(EXTI_LINE_1);//disable exti1
			EXTI->IMR |= ~(EXTI_LINE_2); //enable exti2
		}else{
			//trace_printf("Changing inSIG to 0");
			inSig = 0;
			EXTI->IMR &= ~(EXTI_LINE_2);//disable exti2
			EXTI->IMR |= ~(EXTI_LINE_1);//enable exti1
		}
	}

}

void EXTI2_3_IRQHandler()
{
	// Declare/initialize your local variables here...
	double freq;
	uint32_t count;
	/* Check if EXTI2 interrupt pending flag is indeed set */
	// this reads off function generator
	if ((EXTI->PR & EXTI_PR_PR2) != 0){
		// 1. If this is the first edge:
		//	- Clear count register (TIM2->CNT).
		//	- Start timer (TIM2->CR1).
		//    Else (this is the second edge):
		//	- Stop timer (TIM2->CR1).
		//	- Read out count register (TIM2->CNT).
		//	- Calculate signal period and frequency.
		//	- Print calculated values to the console.
		//	  NOTE: Function trace_printf does not work
		//	  with floating-point numbers: you must use
		//	  "unsigned int" type to print your signal
		//	  period and frequency.
			if((EXTI->PR & EXTI_PR_PR2) != 0){
				if(timerTriggered == 0){
					timerTriggered = 1;
					count = 0;

					TIM2->CNT = 0;

					TIM2->CR1 |= TIM_CR1_CEN;;
				}else{
					timerTriggered = 0;

					TIM2->CR1 &= ~(TIM_CR1_CEN);

					count = TIM2->CNT;

					freq = ((double)SystemCoreClock)/((double)count); // freq=1/period

					trace_printf("Source: Function Generator\n");
					trace_printf("The Frequency is: %f Hz\n", freq);
					trace_printf("The Resistance is: %f ohms\n\n", (float)Potentiometer_resistance());
				}
			}

		// button press in this inttereupt
		if((EXTI->PR & EXTI_PR_PR0) != 0){ // is button pressed?
			while((GPIOA->IDR & GPIO_IDR_0) != 0){} // wait for button
			//trace_printf("\nButton hit\n");
			EXTI->IMR &= ~(EXTI_IMR_MR2); // disable this interupt
		}


		// 2. Clear EXTI2 interrupt pending flag (EXTI->PR).
		// NOTE: A pending register (PR) bit is cleared
		// by writing 1 to it.
		EXTI->PR |= EXTI_PR_PR2;

	}
}

// initialize ADC
void myADC_Init(void){

	// initalize clock for ADC
	RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

//	1. Ensure that ADEN=0
//	2. Set ADCAL=1
//	3. Wait until ADCAL=0
//	4. The calibration factor can be read from bits 6:0 of ADC_DR.

	if ((ADC1->CR & ADC_CR_ADEN) != 0){	// if aden is not 0
		ADC1->CR |= ADC_CR_ADDIS; // clear aden by addis (adc is disabled)
		while ((ADC1->CR & ADC_CR_ADEN) != 0); // timeout for adc disable
	}
	ADC1->CR |= ADC_CR_ADCAL; // calibrate by setting adcal
	while(ADC1->CR & ADC_CR_ADCAL); // timeout until calibration complete


	ADC1->CHSELR = ADC_CHSELR_CHSEL5; // select CHSEL5 for ADC channel 5

	ADC1->SMPR |= 7; // max smp = 0b111 = 7 (239.5 ADC clock cycles)


	// change configuration registers
	ADC1->CFGR1 &= ~ADC_CFGR1_RES; // enable data resolution

	ADC1->CFGR1 &= ~ADC_CFGR1_ALIGN; // right align converted data

	ADC1->CFGR1 |= ADC_CFGR1_OVRMOD; // enable overrun management mode

	ADC1->CFGR1 |= ADC_CFGR1_CONT; // enable continuous conversion mode


	ADC1->CR |= ADC_CR_ADEN; // re enable ADC now that configuration register are changed

	while ((ADC1->ISR & ADC_ISR_ADRDY) == 0); // timeout until ADC re enabled

	ADC1->CR |= ADC_CR_ADSTART; // ADC start (works as aden has been re enabkled)

	trace_printf("ADC initialized\n");
}

// initialize DAC
void myDAC_Init(void){

	RCC->APB1ENR |= RCC_APB1ENR_DACEN;  // enable dac clock

	DAC->CR |= DAC_CR_EN1; // enable channel1 of DAC

	trace_printf("DAC initialized\n");
}


uint32_t Potentiometer_resistance(){
	uint32_t ADC_value = Potentiometer_voltage();

	// Vchannel = ADC_data x (Vdda / Full_scale)
	// ADC_data = ADC_value (read)
	// Vdda = 3.3 V (given)
	// Full_scale = 2^12 - 1 = 4095 with 12 bit resolution (maximum digital value of the ADC output)

	float v_channel = (ADC_value * 3.3f) / (4095.0f);// 4095 = 2^12 - 1

	// Potentiometer_resistance = resistor * (v_channel / (Vdda - v_channel)) via voltage dividor
	//trace_printf("Potentiometer resistance: %f\n", 5000.0f * (v_channel / (3.3f - v_channel)));
	return 5000.0f * (v_channel / (3.3f - v_channel)); // resistance in circuit is given as 5k ohms
}

uint32_t Potentiometer_voltage(){
	return (ADC1->DR & 0xFFF); // masking the result to ensure only lower 12 bits
}

void read_DAC(){
	uint32_t ADC_value = Potentiometer_voltage();
	//trace_printf("ADCvolt: %f\n", (float)ADC_volt);

	float range = 3.3f - 0.7f; //3.3 (Vdda) is max as given, 0.7 is minimum
	//trace_printf("range: %f\n", range);

	float volt = ((ADC_value / 4095.0f) * range) + 0.7f; // via voltage divivodr + voltage offset
	//trace_printf("volt: %f\n", volt);

	uint32_t DAC_value_read = (volt / 3.3f) * 4095.0f; //
	trace_printf("DAC value: %f\n", (float)DAC_value_read);

	DAC->DHR12R1 = DAC_value_read; // store dac value into register

}


#pragma GCC diagnostic pop

// ----------------------------------------------------------------------------
